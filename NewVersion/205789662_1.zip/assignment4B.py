"""
In this assignment you should fit a model function of your choice to data 
that you sample from a contour of given shape. Then you should calculate
the area of that shape. 

The sampled data is very noisy so you should minimize the mean least squares 
between the model you fit and the data points you sample.  

During the testing of this assignment running time will be constrained. You
receive the maximal running time as an argument for the fitting method. You 
must make sure that the fitting function returns at most 5 seconds after the 
allowed running time elapses. If you know that your iterations may take more 
than 1-2 seconds break out of any optimization loops you have ahead of time.

Note: You are allowed to use any numeric optimization libraries and tools you want
for solving this assignment. 
Note: !!!Despite previous note, using reflection to check for the parameters 
of the sampled function is considered cheating!!! You are only allowed to 
get (x,y) points from the given shape by calling sample(). 
"""

import numpy as np
import time
import random

from NewVersion.assignment4A import Assignment4A
from functionUtils import AbstractShape


class MyShape(AbstractShape):
    # change this class with anything you need to implement the shape
    def __init__(self, f:callable):
        pass
        states = ["forward-up", "forward-down"]

        numberofSamples=100



        self._functions=[]
        self._samplesCountForEachFunc=[]
        stateMachine="goingForward"


        #init
        ass4A = Assignment4A()
        pointsArr = []
        prevXi, prevYi = self._fSamples()
        pointsArr.append((prevXi, prevYi))
        newXi, newYi = prevXi, prevYi

        #state-firstDot until starting to go back
        count=0
        while (newXi >= prevXi):
            prevXi, prevXi = newXi, newYi
            pointsArr.append((prevXi, prevYi))
            newXi, newYi = self._fSamples()
            count += 1

        firstX, firstY = pointsArr[0]
        lastX, lastY = pointsArr[-1]

        g1 = ass4A.fit(self._fSamples, firstX, lastX, count)
        self._functions.append(g1)
        self._samplesCountForEachFunc.append(count)










class Assignment4:
    def __init__(self):
        """
        Here goes any one time calculation that need to be made before 
        solving the assignment for specific functions. 
        """

        pass

    def area(self,contour: callable, maxerr=0.001)->np.float32:
        """
        Compute the area of the shape with the given contour. 

        Parameters
        ----------
        contour : callable
            Same as AbstractShape.contour 
        maxerr : TYPE, optional
            The target error of the area computation. The default is 0.001.

        Returns
        -------
        The area of the shape.

        """
        maxFP=np.float32(maxerr)
        n=np.int32((np.float32(1.0))/(maxFP*np.float32(10)))
        pointsArr=contour(n)

        totalArea=0
        count=0
        while (count<n-1):
            xi,yi=pointsArr[count]
            xj,yj=pointsArr[count+1]
            b=xj
            a=xi
            fb=yj
            fa=yi
            curr=(b-a)*((fa+fb)/2)
            totalArea+=curr
            count+=1

        return abs(totalArea)

    
    def fit_shape(self, sample: callable, maxtime: float) -> AbstractShape:
        """
        Build a function that accurately fits the noisy data points sampled from
        some closed shape. 
        
        Parameters
        ----------
        sample : callable. 
            An iterable which returns a data point that is near the shape contour.
        maxtime : float
            This function returns after at most maxtime seconds. 

        Returns
        -------
        An object extending AbstractShape. 
        """

        # replace these lines with your solution

        result = MyShape()
        x, y = sample()

        return result


##########################################################################


import unittest
from sampleFunctions import *
from tqdm import tqdm
import matplotlib.pyplot as plt


class TestAssignment4(unittest.TestCase):

    def test_dor(self):
        ass4 = Assignment4()
        circ = Circle(cx=1, cy=1, radius=1, noise=0.1)
        xxx=circ.contour
        my_area=ass4.area(xxx,0.001)
        self.assertLess(abs(my_area - np.pi), 0.01)

    def test_circle(self):

        xp = []
        yp = []
        circ=noisy_circle(1,1,1,0.1)
        for i in range(100):
            xi,yi=circ()
            xp.append(xi)
            yp.append(yi)
        fig, (ax12) = plt.subplots(nrows=1, ncols=1, sharex=False, figsize=(12, 4))
        ax12.plot(xp, yp, color="blue")
        plt.show()

    def test_return(self):
        circ = noisy_circle(cx=1, cy=1, radius=1, noise=0.1)
        ass4 = Assignment4()
        T = time.time()
        shape = ass4.fit_shape(sample=circ, maxtime=5)
        T = time.time() - T
        self.assertTrue(isinstance(shape, AbstractShape))
        self.assertLessEqual(T, 5)

    def test_delay(self):
        circ = noisy_circle(cx=1, cy=1, radius=1, noise=0.1)

        def sample():
            time.sleep(7)
            return circ()

        ass4 = Assignment4()
        T = time.time()
        shape = ass4.fit_shape(sample=sample, maxtime=5)
        T = time.time() - T
        self.assertTrue(isinstance(shape, AbstractShape))
        self.assertGreaterEqual(T, 5)

    def test_circle_area(self):
        circ = noisy_circle(cx=1, cy=1, radius=1, noise=0.1)
        ass4 = Assignment4()
        T = time.time()
        shape = ass4.fit_shape(sample=circ, maxtime=30)
        T = time.time() - T
        a = shape.area()
        self.assertLess(abs(a - np.pi), 0.01)
        self.assertLessEqual(T, 32)

    def test_bezier_fit(self):
        circ = noisy_circle(cx=1, cy=1, radius=1, noise=0.1)
        ass4 = Assignment4()
        T = time.time()
        shape = ass4.fit_shape(sample=circ, maxtime=30)
        T = time.time() - T
        a = shape.area()
        self.assertLess(abs(a - np.pi), 0.01)
        self.assertLessEqual(T, 32)


if __name__ == "__main__":
    unittest.main()
